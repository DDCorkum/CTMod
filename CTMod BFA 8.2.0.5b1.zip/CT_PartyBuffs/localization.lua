CT_PARTYBUFFS_TOGGLE = { };
CT_PARTYBUFFS_TOGGLE["1"] = "Party Buffs and Pet Buffs are now shown.";
CT_PARTYBUFFS_TOGGLE["2"] = "Only Party Buffs are now shown.";
CT_PARTYBUFFS_TOGGLE["3"] = "Only Pet Buffs are now shown.";
CT_PARTYBUFFS_TOGGLE["4"] = "Party Buffs and Pet Buffs are now hidden.";

CT_PARTYBUFFS_MODNAME1 = "Party Buffs";
CT_PARTYBUFFS_SUBNAME1 = "Shows party buffs";
CT_PARTYBUFFS_TOOLTIP1 = "Shows buffs for each party member below their portrait.\nClicking changes display options.";

CT_PARTYBUFFS_NUMSHOWN = "%d Party Buffs are now shown.";

CT_PARTYBUFFS_MODNAME2 = "Buff Buttons";
CT_PARTYBUFFS_SUBNAME2 = "Toggle Buff #";
CT_PARTYBUFFS_TOOLTIP2 = "Changes how many buffs are shown for party members";