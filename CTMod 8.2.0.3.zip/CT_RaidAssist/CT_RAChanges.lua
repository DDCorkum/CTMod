------------------------------------------------
-- CONTENT REMOVED IN 8.1.5.2
-- This wasn't being maintained since 5.3 anyways
-- and is now integrated into CT_RASlashCmds.lua
-- with a much simpler, less bloated solution
------------------------------------------------
 
