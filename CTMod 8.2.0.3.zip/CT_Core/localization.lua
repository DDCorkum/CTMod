local module = CT_Core;

BINDING_HEADER_CT_CORE = "CT_Core";
BINDING_NAME_CT_CORE_HAIL = "Hail";

module:setText("EDITING", "Set note for %s:");
module:setText("EDITNOTE", "Edit Note", "Notiz Bearbeiten", "Editer Note");
module:setText("CLICKEDIT", "Click to edit", "Klicken zum bearbeiten", "Cliquer pour \195\169diter");