if ( GetLocale() == "deDE" ) then
	-- Credits to Hj�rvar�r for these
	CT_UFO_PARTYTEXTSIZE = "Textgr\195\182\195\159e";
	CT_UFO_PARTYTEXTSIZE_LARGE = "Gro\195\159";
	CT_UFO_PARTYTEXTSIZE_SMALL = "Klein";
end