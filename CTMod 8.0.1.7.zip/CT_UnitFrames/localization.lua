-- UnitFramesOptions
CT_UFO_RADIO = { "None", "Percent", "Deficit", "Values", "Current" };
CT_UFO_SELECTION = { "On Health Bar:", "Beside Health Bar:", "On Mana Bar:", "Beside Mana Bar:" };
CT_UFO_SELECTION2 = { "On Health Bar:", "Beside Health Bar:", "On Mana Bar:", "Beside Mana Bar:", "Enemy Health Bar:" };
CT_UFO_BOX = { "Player Frame", "Party Frames", "Target Frame", "Assist (Target of Target) Frame", "Focus Frame" };
CT_UFO_TARGETCLASS = "Show the class";
CT_UFO_PARTYTEXTSIZE = "Text Size";
CT_UFO_PARTYTEXTSIZE_LARGE = "Large";
CT_UFO_PARTYTEXTSIZE_SMALL = "Small";
CT_UFO_TARGETOFASSIST = "Show the target";
CT_UFO_ASSISTCASTBAR = "Show the casting bar";
CT_UFO_TARGETOFFOCUS = "Show the target";
CT_UFO_FOCUSCASTBAR = "Show the casting bar";
CT_UFO_TEXTSPACING_HELP = "Allows you to change the distance between the unit frame and the health/mana text that is shown beside the unit frame.";
CT_UFO_LEFTSPACING = "Beside health/mana bar spacing = ";
CT_UFO_RIGHTSPACING = "Beside health/mana bar spacing = ";
CT_UFO_TEXTRIGHT = "Show health/mana on right side";
CT_UFO_TEXTLEFT = "Show health/mana on left side";
CT_UFO_SHOWCOORDS = "Show player coordinates";
